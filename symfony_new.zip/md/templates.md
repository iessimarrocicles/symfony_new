# Plantilla per copiar

!!! warning "Warning: Atenció amb les rutes amigables"
    Recordar repetir aquestes instruccions en tots els projectes Symfony que utilitzen rutes amigables.

!!! example "Example: Atenció amb les rutes amigables"
    Recordar repetir aquestes instruccions en tots els projectes Symfony que utilitzen rutes amigables.

!!! tip "Tip: Atenció amb les rutes amigables"
    Recordar repetir aquestes instruccions en tots els projectes Symfony que utilitzen rutes amigables.

!!! important "Important: Atenció amb les rutes amigables"
    Recordar repetir aquestes instruccions en tots els projectes Symfony que utilitzen rutes amigables.

!!! danger "Danger: Atenció amb les rutes amigables"
    Recordar repetir aquestes instruccions en tots els projectes Symfony que utilitzen rutes amigables.

!!!note "Note: Atenció amb les rutes amigables"
    Recordar repetir aquestes instruccions en tots els projectes Symfony que utilitzen rutes amigables.

🧠 **Explicació del funcionament**

- ...
- ...

> ⚠️ Si ...

💡 En ...

📝 Notes:

- ...
- ...

**Fitxer:** `base.html.twig`

**Fitxer (`base.html.twig`)**

→
